<script>
export default {
	// 定义name包含keep-alive，离开本页面再次返回时不刷新页面
	// 只在onActivated中更新数据
	name: 'sum_tripInfo_keep-alive'
}
</script>

<script setup>
const router = VueRouter.useRouter();

const data = Vue.ref({});
const dt = new Date();
const thisYear = dt.getFullYear();
const thisMonth = dt.getMonth();
const thisDate = dt.getDate();
const formData = Vue.ref({
    daily: {
        date: new Date(thisYear, thisMonth, thisDate),
        dateStr: '今天'
    },
    monthly: {
        date: new Date(thisYear, thisMonth, 1),
        dateStr: '本月'
    },
    yearly: {
        date: new Date(thisYear, 0, 1),
        dateStr: '今年'
    }
});

const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    let minutes = Math.floor((seconds % 3600) / 60);
    minutes = minutes < 10 ? '0' + minutes : minutes;
    return hours + ':' + minutes;
}
const setDate = (val) => {
    if (val === 0) {
        formData.value.daily.date = new Date(thisYear, thisMonth, thisDate);
    } else {
        // 直接setDate修改不会触发watch，这里转一下再赋值
        const d = new Date(formData.value.daily.date.toDateString());
        d.setDate(d.getDate() + val);
        formData.value.daily.date = d;
    }
}
Vue.watch(() => formData.value.daily.date, () => {
    if (formData.value.daily.date.getFullYear() === thisYear
        && formData.value.daily.date.getMonth() === thisMonth
        && formData.value.daily.date.getDate() === thisDate
    ) {
        formData.value.daily.dateStr = '今天';
    } else if (formData.value.daily.date.getFullYear() === thisYear) {
        formData.value.daily.dateStr = formData.value.daily.date.Format('MM月DD日');
    } else {
        formData.value.daily.dateStr = formData.value.daily.date.Format('YYYY年MM月DD日');
    }
    getDailyData();
});
const getDailyData = async () => {
    const res = await axios({
        url: 'api/sum_tripInfo.php',
        method: 'get',
        params: {
            date: formData.value.daily.date.Format('YYYY-MM-DD')
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    data.value.daily = res.data.data;
}

const setMonth = (val) => {
    if (val === 0) {
        formData.value.monthly.date = new Date(thisYear, thisMonth, 1);
    } else {
        const d = new Date(formData.value.monthly.date.toDateString());
        d.setMonth(d.getMonth() + val);
        formData.value.monthly.date = d;
    }
}
Vue.watch(() => formData.value.monthly.date, () => {
    const theDate = formData.value.monthly.date;
    if (theDate.getFullYear() === thisYear && theDate.getMonth() === thisMonth) {
        formData.value.monthly.dateStr = '本月';
    } else if (theDate.getFullYear() === thisYear) {
        formData.value.monthly.dateStr = theDate.Format('MM月');
    } else {
        formData.value.monthly.dateStr = theDate.Format('YYYY年MM月');
    }
    getMonthlyData();
});
const getMonthlyData = async () => {
    const theDate = formData.value.monthly.date;
    const res = await axios({
        url: 'api/sum_tripInfo.php',
        method: 'get',
        params: {
            dateFrom: theDate.Format('YYYY-MM-01'),
            dateTo: new Date(theDate.getFullYear(), theDate.getMonth() + 1, 0).Format('YYYY-MM-DD')
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    data.value.monthly = res.data.data;
}

const setYear = (val) => {
    if (val === 0) {
        formData.value.yearly.date = new Date(thisYear, 0, 1);
    } else {
        const d = new Date(formData.value.yearly.date.toDateString());
        d.setFullYear(d.getFullYear() + val);
        formData.value.yearly.date = d;
    }
}
Vue.watch(() => formData.value.yearly.date, () => {
    if (formData.value.yearly.date.getFullYear() === thisYear) {
        formData.value.yearly.dateStr = '今年';
    } else {
        formData.value.yearly.dateStr = formData.value.yearly.date.Format('YYYY年');
    }
    getYearlyData();
});
const getYearlyData = async () => {
    const res = await axios({
        url: 'api/sum_tripInfo.php',
        method: 'get',
        params: {
            dateFrom: formData.value.yearly.date.Format('YYYY-01-01'),
            dateTo: formData.value.yearly.date.Format('YYYY-12-31')
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    data.value.yearly = res.data.data;
}


const toTripList = () => {
    router.push({
        path: '/tripList',
        query: {
            date: formData.value.daily.date.Format('YYYY-MM-DD')
        }
    });
}
const toMonthlyTrip = () => {
    router.push({
        path: '/monthlyTrip',
        query: {
            date: formData.value.monthly.date.Format('YYYY-MM-01')
        }
    });
}
const toElecCharging = () => {
    router.push({
        path: '/elecCharging',
        query: {
            date: formData.value.yearly.date.Format('YYYY-01-01')
        }
    });
}

// 只有keep-alive的页面生命周期中有onActivated
Vue.onActivated(() => {
    getDailyData();
    getMonthlyData();
    getYearlyData();
    getPrices();
});
// 油价/电价(概览页直接编辑)
const prices = Vue.ref({ fuel_price: 8, elec_price: 0.55 });
const getPrices = async () => {
    const res = await axios({ url: 'api/sum_set_price.php', method: 'get' });
    if (res.data.success == 1) prices.value = res.data.data;
};
const savePrices = async () => {
    const res = await axios({ url: 'api/sum_set_price.php', method: 'post', data: prices.value });
    if (res.data.success == 1) {
        ElementPlus.ElMessage.success('油价/电价已保存');
        getPrices();
    } else {
        ElementPlus.ElMessage.error(res.data.message);
    }
};
</script>

<template>
    <div class="tab-head">
        <div class="tab-head-title">概览</div>
    </div>
    <div class="container">
        <el-card body-class="el-card-body-class">
            <template #header>
                <div class="price-inline">
                    <span class="price-item">油价(元/L)</span>
                    <el-input-number v-model="prices.fuel_price" :min="0" :step="0.1" size="small" style="width:110px"/>
                    <span class="price-item">电价(元/kWh)</span>
                    <el-input-number v-model="prices.elec_price" :min="0" :step="0.01" size="small" style="width:110px"/>
                    <el-button type="primary" size="small" @click="savePrices">保存</el-button>
                </div>
            </template>
            <el-descriptions border :column="2" :title="formData.daily.dateStr">
                <template #extra>
                    <el-space size="large">
                        <el-button type="primary" plain @click="setDate(-1)"><</el-button>
                        <el-date-picker v-model="formData.daily.date" :editable="false" style="width: 120px"/>
                        <el-button type="primary" plain @click="setDate(1)">></el-button>
                    </el-space>
                </template>
                <el-descriptions-item label="行驶里程">
                    {{ data.daily?.mileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="行驶时间">
                    {{ data.daily?.travelTime ? formatTime(data.daily?.travelTime) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="出行次数">
                    {{ data.daily?.travelCnt ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="平均时间">
                    {{ data.daily?.avgTime ? formatTime(data.daily?.avgTime) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="纯电里程">
                    {{ data.daily?.evMileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="混动里程">
                    {{ data.daily?.mileage ? Math.max(0, Math.round((data.daily?.mileage - data.daily?.evMileage) * 10) / 10) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="电量消耗">{{ data.daily?.elecCon ?? 0 }}</el-descriptions-item>
                <el-descriptions-item label="油量消耗">{{ data.daily?.fuelCon ?? 0 }}</el-descriptions-item>
                <el-descriptions-item label="百公里电">
                    {{ data.daily?.mileage ? Math.round(data.daily?.elecCon / data.daily?.mileage * 1000) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="百公里油">
                    {{ data.daily?.mileage ? Math.round(data.daily?.fuelCon / data.daily?.mileage * 1000) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="耗电费用">
                    {{ data.daily?.totalElecCon ? Math.round(data.daily.totalElecCon * data.daily.elec_price * 100) / 100 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="耗油费用">
                    {{ data.daily?.totalFuelCon ? Math.round(data.daily.totalFuelCon * data.daily.fuel_price * 100) / 100 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="充电费用">
                    {{ data.daily?.totalElecCharged ? Math.round(data.daily.totalElecCharged * data.daily.elec_price * 100) / 100 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="充电度数">
                    {{ data.daily?.totalElecCharged || 0 }}
                </el-descriptions-item>
            </el-descriptions>
            <p>
                <el-link type="primary" @click="toTripList">查看详情</el-link>
            </p>
        </el-card>

        <el-card body-class="el-card-body-class">
            <el-descriptions border :column="2" :title="formData.monthly.dateStr">
                <template #extra>
                    <el-space size="large">
                        <el-button type="primary" plain @click="setMonth(-1)"><</el-button>
                        <el-date-picker
                            v-model="formData.monthly.date"
                            :editable="false"
                            type="month"
                            style="width: 120px"
                        />
                        <el-button type="primary" plain @click="setMonth(1)">></el-button>
                    </el-space>
                </template>
                <el-descriptions-item label="行驶里程">
                    {{ data.monthly?.mileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="表显里程">
                    {{ data.monthly?.totalMileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="行驶时间">
                    {{ data.monthly?.travelTime ? formatTime(data.monthly?.travelTime) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="出行天数">
                    {{ data.monthly?.travelDays ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="日均里程">
                    {{ data.monthly?.travelDays ? Math.round(data.monthly?.mileage / data.monthly.travelDays * 10) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="日均时间">
                    {{ data.monthly?.travelDays ? formatTime(Math.round(data.monthly?.travelTime / data.monthly.travelDays)) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="纯电里程">
                    {{ data.monthly?.evMileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="混动里程">
                    {{ data.monthly?.mileage ? Math.max(0, Math.round((data.monthly?.mileage - data.monthly?.evMileage) * 10) / 10) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="电量消耗">{{ data.monthly?.elecCon ?? 0 }}</el-descriptions-item>
                <el-descriptions-item label="油量消耗">{{ data.monthly?.fuelCon ?? 0 }}</el-descriptions-item>
                <el-descriptions-item label="百公里电">
                    {{ data.monthly?.mileage ? Math.round(data.monthly?.elecCon / data.monthly?.mileage * 1000) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="百公里油">
                    {{ data.monthly?.mileage ? Math.round(data.monthly?.fuelCon / data.monthly?.mileage * 1000) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="表显能耗" :span="2">
                    {{
                        data.monthly?.totalMileage ?
                        '百公里 ' +
                        Math.round(data.monthly?.totalElecCon / data.monthly.totalMileage * 1000) / 10 + 'kWh 电 + ' +
                        Math.round(data.monthly?.totalFuelCon / data.monthly.totalMileage * 1000) / 10 + 'L 油'
                        : 0
                    }}
                </el-descriptions-item>
                <el-descriptions-item label="耗电费用">
                    {{ data.monthly?.totalElecCon ? Math.round(data.monthly.totalElecCon * data.monthly.elec_price * 100) / 100 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="耗油费用">
                    {{ data.monthly?.totalFuelCon ? Math.round(data.monthly.totalFuelCon * data.monthly.fuel_price * 100) / 100 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="充电费用">
                    {{ data.monthly?.totalElecCharged ? Math.round(data.monthly.totalElecCharged * data.monthly.elec_price * 100) / 100 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="充电度数">
                    {{ data.monthly?.totalElecCharged || 0 }}
                </el-descriptions-item>
            </el-descriptions>
            <p>
                <el-link type="primary" @click="toMonthlyTrip">查看详情</el-link>
            </p>
        </el-card>

        <el-card body-class="el-card-body-class">
            <el-descriptions border :column="2" :title="formData.yearly.dateStr">
                <template #extra>
                    <el-space size="large">
                        <el-button type="primary" plain @click="setYear(-1)"><</el-button>
                        <el-date-picker
                            v-model="formData.yearly.date"
                            :editable="false"
                            type="year"
                            style="width: 120px"
                        />
                        <el-button type="primary" plain @click="setYear(1)">></el-button>
                    </el-space>
                </template>
                <el-descriptions-item label="行驶里程">
                    {{ data.yearly?.mileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="表显里程">
                    {{ data.yearly?.totalMileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="行驶时间">
                    {{ data.yearly?.travelTime ? formatTime(data.yearly?.travelTime) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="出行天数">
                    {{ data.yearly?.travelDays ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="日均里程">
                    {{ data.yearly?.travelDays ? Math.round(data.yearly?.mileage / data.yearly.travelDays * 10) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="日均时间">
                    {{ data.yearly?.travelDays ? formatTime(Math.round(data.yearly?.travelTime / data.yearly.travelDays)) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="纯电里程">
                    {{ data.yearly?.evMileage ?? 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="混动里程">
                    {{ data.yearly?.mileage ? Math.max(0, Math.round((data.yearly?.mileage - data.yearly?.evMileage) * 10) / 10) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="电量消耗">{{ data.yearly?.elecCon ?? 0 }}</el-descriptions-item>
                <el-descriptions-item label="油量消耗">{{ data.yearly?.fuelCon ?? 0 }}</el-descriptions-item>
                <el-descriptions-item label="百公里电">
                    {{ data.yearly?.mileage ? Math.round(data.yearly?.elecCon / data.yearly?.mileage * 1000) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="百公里油">
                    {{ data.yearly?.mileage ? Math.round(data.yearly?.fuelCon / data.yearly?.mileage * 1000) / 10 : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="表显能耗" :span="2">
                    {{
                        data.yearly?.totalMileage ?
                        '百公里 ' +
                        Math.round(data.yearly?.totalElecCon / data.yearly.totalMileage * 1000) / 10 + 'kWh 电 + ' +
                        Math.round(data.yearly?.totalFuelCon / data.yearly.totalMileage * 1000) / 10 + 'L 油'
                        : 0
                    }}
                </el-descriptions-item>
                <el-descriptions-item label="耗电费用">
                    {{ data.yearly?.totalElecCon ? Math.round(data.yearly.totalElecCon * data.yearly.elec_price) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="耗油费用">
                    {{ data.yearly?.totalFuelCon ? Math.round(data.yearly.totalFuelCon * data.yearly.fuel_price) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="充电费用">
                    {{ data.yearly?.totalElecCharged ? Math.round(data.yearly.totalElecCharged * data.yearly.elec_price) : 0 }}
                </el-descriptions-item>
                <el-descriptions-item label="充电度数">
                    {{ data.yearly?.totalElecCharged || 0 }}
                </el-descriptions-item>
            </el-descriptions>
            <p>
                <el-link type="primary" @click="toElecCharging">查看充电/里程详情</el-link>
            </p>
        </el-card>
    </div>
</template>

<style>
.price-inline {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 6px 10px;
    width: 100%;
}
.price-inline .price-item {
    font-size: 13px;
    color: #606266;
    white-space: nowrap;
}
@media (max-width: 768px) {
    .el-card-body-class {
        padding-left: 10px;
        padding-right: 10px;
    }
    .price-inline {
        justify-content: flex-start;
        gap: 4px 6px;
    }
    .price-inline .price-item {
        font-size: 12px;
    }
    .price-inline .el-input-number {
        width: 82px !important;
    }
    .price-inline .el-button {
        padding: 6px 10px;
        font-size: 12px;
    }
}
</style>
<style scoped>
.container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 40px;
    width: 100%;
    margin-bottom: 40px;
}
.container .el-card {
    position: relative;
}
</style>