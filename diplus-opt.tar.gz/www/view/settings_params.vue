<script setup>
import { ref, defineAsyncComponent } from 'vue';

const tab = ref('cmd');
const CmdC = defineAsyncComponent(() => loadVueModule('./view/settings_cmd.vue'));
const DipC = defineAsyncComponent(() => loadVueModule('./view/settings_diparams.vue'));
const MntC = defineAsyncComponent(() => loadVueModule('./view/settings_maint.vue'));
</script>

<template>
    <el-tabs v-model="tab" class="params-tabs">
        <el-tab-pane label="远程设置" name="cmd"><CmdC /></el-tab-pane>
        <el-tab-pane label="车况显示" name="dip"><DipC /></el-tab-pane>
        <el-tab-pane label="维保显示" name="mnt"><MntC /></el-tab-pane>
    </el-tabs>
</template>

<style scoped>
.params-tabs :deep(.el-tabs__header) {
    margin: 0 0 8px;
}
.params-tabs :deep(.el-tabs__item) {
    font-size: 13px;
    padding: 0 12px;
}
</style>
