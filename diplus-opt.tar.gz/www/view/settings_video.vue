<script setup>
</script>

<template>
    <iframe src="video_list.html" width="100%" height="900px" style="border: none" class="page-iframe"></iframe>
</template>

<style scoped>
@media (max-width: 767px) {
    .page-iframe {
        height: calc(100vh - 76px) !important;
    }
}
</style>
