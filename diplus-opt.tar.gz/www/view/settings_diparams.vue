<script setup>
import elSelectX from '/includes/vue-components/el-select-x.vue';
import sortable from '/includes/vue-components/sortable/sortable.vue';

const formData = Vue.ref({
    preset_params: {},
    diplus_params: [],
    tracking: { snapshot: 'diplus', trigger_for_tracking: false }
});
const options = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/settings_diparams.php',
        method: 'get'
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
    options.value = res.data.options;
}
const getTracking = async () => {
    try {
        const res = await axios({ url: 'api/settings_tracking.php', method: 'get' });
        if (res.data.success >= 1 && res.data.data) {
            formData.value.tracking = Object.assign({ snapshot: 'diplus', trigger_for_tracking: false }, res.data.data);
        }
    } catch (e) {}
}
getData();
getTracking();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }

    const res = await axios({
        url: 'api/settings_diparams.php',
        method: 'post',
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    // 同时保存行驶轨迹设置
    try {
        await axios({ url: 'api/settings_tracking.php', method: 'post', data: formData.value.tracking });
    } catch (e) {}
    getData();
    getTracking();
}
const dataTypeOptions = [
    {
        label: '数值',
        value: 'number'
    },
    {
        label: '描述',
        value: 'description'
    }
];
const addParam = () => {
    const len = formData.value.diplus_params?.length;
    const row = {
        uid: uid(),
        label: '参数' + (len + 1),
        name: '',
        dataType: 'number',
        factor: 1,
        precision: 0,
        show: true,
        save: false,
        monitor: false
    }
    if (!len) {
        formData.value.diplus_params = [];
    }
    formData.value.diplus_params.push(row);
}
const deleteParam = (index) => {
    formData.value.diplus_params.splice(index, 1);
}
const checkParam = (param) => {
    if (options.value.FIXED_DRIVING_PARAMS.includes(param.name)) {
        param.save = true;
    }
    param.label = param.name;
}
</script>

<template>
    <div class="tab-head">
        <div class="tab-head-title">车况数据</div>
    </div>

    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <el-card style="margin-bottom: 20px;" header="预设参数">
            <el-form-item prop="preset_params.show_position">
                    <el-switch v-model="formData.preset_params.show_position" active-text="显示车辆位置"/>
            </el-form-item>
            <div v-if="formData.preset_params.tire_pressure" class="inline-form-items">
                <el-form-item prop="preset_params.tire_pressure">
                    <el-switch v-model="formData.preset_params.tire_pressure.show" active-text="在首页图片四角显示轮胎气压"/>
                </el-form-item>
                <el-form-item v-if="formData.preset_params.tire_pressure.show" label="轮胎气压正常范围">
                    <el-space>
                        <el-input v-model="formData.preset_params.tire_pressure.lowerLimit" placeholder="下限"/>
                        <span>~</span>
                        <el-input v-model="formData.preset_params.tire_pressure.upperLimit" placeholder="上限"/>
                    </el-space>
                </el-form-item>
            </div>
            <el-form-item prop="autorefresh_params">
                <el-switch v-model="formData.autorefresh_params" active-text="自动刷新车况数据"/>
            </el-form-item>
        </el-card>

        <el-card style="margin-bottom: 20px;" header="行驶轨迹设置">
            <el-form-item prop="tracking.snapshot" label="行驶轨迹地图显示视频截图">
                <el-radio-group v-model="formData.tracking.snapshot">
                    <el-radio value="diplus">优先显示迪加记录仪视频截图</el-radio>
                    <el-radio value="byd">优先显示原车记录仪视频截图</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item prop="tracking.trigger_for_tracking">
                <el-switch v-model="formData.tracking.trigger_for_tracking" active-text="自动设置迪加自动化"/>
            </el-form-item>
        </el-card>

        <el-collapse style="margin: 30px 5px">
            <sortable v-model="formData.diplus_params" handle=".collapse-title">
                <el-collapse-item
                    v-for="(row, index) in formData.diplus_params"
                    :key="row.uid"
                    :name="row.uid"
                >
                    <template #title>
                        <div class="collapse-header">
                            <span class="collapse-title">{{ row.label }}</span>
                            <el-space>
                                <el-tag v-if="row.monitor" type="warning" round size="small">监听</el-tag>
                                <el-tag
                                    v-if="row.save || options.FIXED_DRIVING_PARAMS.includes(row.name)"
                                    type="success"
                                    round size="small"
                                >保存</el-tag>
                                <el-tag v-if="row.show" type="primary" round size="small">显示</el-tag>
                            </el-space>
                        </div>
                    </template>
                    <div class="inline-form-items">
                        <el-form-item label="迪加自动化参数" :prop="`diplus_params[${index}].name`" :rules="rules">
                            <el-select-x
                                v-model="row.name"
                                :options="options.DIPLUS_PARAM_LIST"
                                filterable
                                @change="checkParam(row)"
                            />
                        </el-form-item>
                        <el-form-item label="显示参数名" :prop="`diplus_params[${index}].label`" :rules="rules">
                            <el-input v-model="row.label"/>
                        </el-form-item>
                    </div>
                    <div class="inline-form-items">
                        <el-form-item label="数据类型 / 系数 / 小数" :prop="`diplus_params[${index}].dataType`" :rules="rules">
                            <el-space>
                                <el-select-x v-model="row.dataType" :options="dataTypeOptions" :clearable="false" min-width="100px"/>
                                <el-input-number v-if="row.dataType == 'number'"
                                    v-model="row.factor"
                                    style="width: 100px"
                                    title="换算系数"
                                    placeholder="系数"
                                />
                                <el-input-number v-if="row.dataType == 'number'"
                                    v-model="row.precision"
                                    :min="0"
                                    :precision="0"
                                    style="width: 100px"
                                    title="小数点位数"
                                    placeholder="小数"
                                />
                            </el-space>
                        </el-form-item>
                        <el-form-item label="数据标准值">
                                <el-input v-model="row.std" placeholder="标准值"/>
                          </el-form-item>
                    </div>
                    <div class="inline-form-items">
                        <el-form-item v-if="!row.std?.length" label="数据正常范围">
                            <el-space>
                                <el-input-number v-model="row.lowerLimit" placeholder="下限"/>
                                <span>~</span>
                                <el-input-number v-model="row.upperLimit" placeholder="上限"/>
                            </el-space>
                        </el-form-item>
                        <el-form-item label="显示数据">
                            <el-switch v-model="row.show" active-text="在首页显示数据"/>
                        </el-form-item>
                    </div>
                    <div class="inline-form-items">
                        <el-form-item>
                            <el-switch
                                v-model="row.save"
                                active-text="保存数据"
                                :disabled="options.FIXED_DRIVING_PARAMS.includes(row.name) || row.monitor"
                            />
                        </el-form-item>
                        <el-form-item>
                            <el-switch v-model="row.monitor" active-text="监听参数, 数据有变化时保存" @change="row.monitor ? row.save = true : null"/>
                        </el-form-item>
                    </div>

                    <div class="collapse-footer">
                        <el-button type="primary" @click="submitForm">保存</el-button>
                        <el-button type="danger"  @click="deleteParam(index)">删除</el-button>
                    </div>
                </el-collapse-item>
            </sortable>
        </el-collapse>
        <el-form-item prop="save_param_interval" label="保存数据最小间隔(分钟)" :rules="rules">
            <el-input-number v-model="formData.save_param_interval" :min="1"/>
        </el-form-item>
    </el-form>

    <el-collapse accordion class="desc">
        <el-collapse-item key="setting_desc" name="setting_desc">
            <template #title>
                设置说明&nbsp;<span class="iconfont icon-info-circle orange"></span>
            </template>
            <el-text tag="div">
                1. 获取车况数据功能依赖于迪加APP，需要车机安装迪加 1.3.7b6 及以上版本。
            </el-text>
            <el-text tag="div">
                2. 系统会在小迪扩展中创建一条名为 <span style="color: orange">Termux-保存车况数据</span> 的扩展，
                此扩展占用迪加<span style="color:orange">变量50</span>，自建小迪扩展/自动化时请勿使用此变量。
            </el-text>
            <el-text tag="div">
                3. 如选择“监听参数，数据有变化时保存”，将会自动创建一条“Termux-监听并保存xxx”的迪加自动化配置。
            </el-text>
            <el-text tag="div">
                4. “保存数据”选项不可取消的是内置固定参数，每次保存其他参数时这些参数也会被保存。
            </el-text>
            <el-text tag="div">
                5. 异常数据显示规则：
                不等于标准值显示<span style="color: #E6A23C">黄色</span>，
                低于下限显示<span style="color: #409EFF">蓝色</span>，
                高于上限显示<span style="color: #F56C6C">红色</span>。设置标准值将忽略上下限值。
            </el-text>
        </el-collapse-item>
    </el-collapse>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
        <el-button type="success" plain @click="addParam">+ 添加参数</el-button>
    </page-footer>
</template>

<style scoped>
.collapse-header {
    width: 100%;
    padding-left: 10px;
    padding-right: 20px;
    display: flex;
    flex-wrap: wrap;
	justify-content: space-between;
	gap: 10px;
	align-items: center;
}
.collapse-title {
    font-weight: bold;
}
.collapse-footer {
    margin-top: 20px;
    display: flex;
    justify-content: right;
    gap: 20px;
}
.desc {
    margin: 40px 0;
}
.desc .el-text {
    margin: 10px 0;
}
</style>