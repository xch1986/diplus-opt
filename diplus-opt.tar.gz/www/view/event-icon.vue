<template>
    <span v-if="showIcon" :class="[ 'event-icon', eventIcons[eventType] ]"></span>
</template>

<script setup>
loadStylesheet('/includes/iconfont/iconfont.css');

const props = defineProps({
    fileNameBase64: String,
    eventType: String,
    personCount: {
        type: [Number, String],
        default: undefined
    },
    carCount: {
        type: [Number, String],
        default: undefined
    },
    color: {
        type: String,
        default: 'red'
    }
});

const eventIcons = Vue.ref({
    person: 'iconfont icon-user',
    car: 'iconfont icon-car-fill'
});

const showIcon = Vue.computed(() => {
	if (props.personCount !== undefined || props.carCount !== undefined) {
		if (props.eventType == 'person') return Number(props.personCount) >= 10;
		if (props.eventType == 'car') return Number(props.carCount) >= 10;
		return false;
	}
	const fileName = decodeURIComponent(atob(props.fileNameBase64));
	const match = fileName.match(/\.(\d{1,2}|100)_(\d{1,2}|100)\.mp4$/i);
	if (!match) return false;
	if (props.eventType == 'person' && parseInt(match[1]) > 0) return true;
	if (props.eventType == 'car' && parseInt(match[2]) > 0) return true;
	return false;
});
</script>

<style scoped>
.event-icon {
    color: v-bind(color);
}
</style>
