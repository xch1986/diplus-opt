<template>
    <div v-if="events.length > 0" class="events-bar">
        <div class="events-bar-inner">
            <div v-for="(row, index) in events" 
                :key="index" 
                class="events-bar-marker"
                :style="{ left: `${row.percent}%`, width: `${row.width}%` }"
            ></div>
        </div>
    </div>
</template>

<script setup>
const props = defineProps({
    startTime: Number,
    endTime: Number,
    eventsData: {
        type: Array,
        default: []
    },
    color: {
        type: String,
        default: 'red'
    }
});

const events = Vue.computed(() => {
    if (!props.startTime || !props.endTime || props.eventsData.length === 0) {
        return [];
    }
    const rangeMS = props.endTime - props.startTime;
    if (rangeMS <= 0) return [];
    const arr = [];
    for (let timeOffsetMS of props.eventsData) {
        if (timeOffsetMS < 0 || timeOffsetMS > rangeMS) continue;
        const percent = (timeOffsetMS / rangeMS) * 100;
        let width = (1000 / rangeMS) * 100;
        width = Math.min(width, 100 - percent);
        width = Math.max(width, 0);
        arr.push({
            percent: Number(percent.toFixed(2)),
            width: Number(width.toFixed(2))
        });
    };
    return arr;
});
</script>

<style scoped>
.events-bar {
    width: 100%;
    padding: 0 15px;
    background-color: black;
}
.events-bar-inner {
    position: relative;
    height: 2px;
}
.events-bar-marker {
    position: absolute;
    height: 100%;
    background-color: v-bind(color);
    top: 0;
}
</style>