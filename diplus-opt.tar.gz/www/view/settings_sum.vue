<script setup>
</script>

<template>
    <div class="tab-head">
        <div class="tab-head-title">行驶数据·能耗·费用</div>
    </div>

    <iframe src="sum.html?v=7" width="100%" height="900px" style="border: none" class="page-iframe"></iframe>
</template>

<style scoped>
@media (max-width: 767px) {
    .page-iframe {
        height: calc(100vh - 130px) !important;
    }
}
</style>
