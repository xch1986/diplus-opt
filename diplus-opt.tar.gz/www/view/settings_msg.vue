<script setup>
import elSelectX from '/includes/vue-components/el-select-x.vue';

const formData = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/settings_msg.php',
        method: 'get',
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
    const ensureAlarm = (key, title, text) => {
        const v = formData.value[key];
        if (!v || Array.isArray(v) || typeof v != 'object') {
            formData.value[key] = { enable: false, reliability: 30, min: 10000, title: title, text: text, shakeG: 10, vibrateGyro: 10 };
        } else {
            if (v.shakeG == null) v.shakeG = 10;
            if (v.vibrateGyro == null) v.vibrateGyro = 10;
        }
    };
    ensureAlarm('trigger_alarm_person', '比亚迪-有人靠近', '有人靠近车辆(可信度{AI识别人可信度})');
    ensureAlarm('trigger_alarm_car', '比亚迪-有车经过', '有车经过车辆(可信度{AI识别车可信度})');
}
getData();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }
    const res = await axios({
        url: 'api/settings_msg.php',
        method: 'post',
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}
const cmd = Vue.ref({
    person: 'HTTPPOST:http://localhost:8018/api/alarm.php?aiType=1'
        + '&triggerTime={上次哨兵触发时间}&triggerImg={上次哨兵触发画面}&title=比亚迪-有人靠近车辆&text=有人靠近车辆(可信度{AI识别人可信度})',
    car: 'HTTPPOST:http://localhost:8018/api/alarm.php?aiType=2'
        + '&triggerTime={上次哨兵触发时间}&triggerImg={上次哨兵触发画面}&title=比亚迪-有车经过&text=有车经过(可信度{AI识别车可信度})',
    msg: 'HTTPPOST:http://localhost:8018/api/send_msg.php?text=车内温度{车内温度}%2C\n车外温度{车外温度}'
});
const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(function() {
        ElementPlus.ElMessage.success('自动化指令已复制到剪贴板！');
    }).catch((error) => {
        ElementPlus.ElMessage.success(`复制指令失败！${error}`);
    });
}
const msgToOptions = Vue.ref([
    {
        label: '不推送',
        value: ''
    },
    {
        label: '微信',
        value: 'wechat'
    },
    {
        label: '钉钉',
        value: 'dingding'
    }
]);
const sendPicOptions = Vue.ref([
    {
        label: '图文混合推送（小图）',
        value: 1
    },
    {
        label: '图文分开推送（大图）',
        value: 2
    }
]);
</script>

<template>
    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <div class="tab-head">
            <div class="tab-head-title">推送报警/提醒信息</div>
            <div>
                <el-select-x v-model="formData.msgTo" :options="msgToOptions" :clearable="false"/>
            </div>
        </div>
        <div v-if="formData.msgTo">
            <el-card header="系统设置">
                <div v-if="formData.msgTo == 'wechat'">
                    <el-form-item prop="WECHAT_ALARM" label="报警机器人webhook" :rules="rules">
                        <el-input
                            v-model="formData.WECHAT_ALARM"
                            type="textarea"
                            autosize
                            placeholder="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxxx"
                        />
                    </el-form-item>
                    <el-form-item prop="WECHAT_MSG" :rules="rules">
                        <template #label>
                            通知机器人webhook
                            <el-tooltip placement="top-start" content="可以和报警机器人相同">
                                <span class="iconfont icon-question-circle tooltip"></span>
                            </el-tooltip>
                        </template>
                        <el-input
                            v-model="formData.WECHAT_MSG"
                            type="textarea"
                            autosize
                            placeholder="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxxx"
                        />
                    </el-form-item>
                    <el-form-item prop="serverIp" :rules="rules">
                        <template #label>
                            从微信跳转本系统的地址
                            <el-tooltip placement="top-start" content="http://域名或IP:8018 或者 Frp反代到8018端口后填写反代地址">
                                <span class="iconfont icon-question-circle tooltip"></span>
                            </el-tooltip>
                        </template>
                        <el-input v-model="formData.serverIp" placeholder="http://域名或IP:8018"/>
                    </el-form-item>
                </div>

                <div v-if="formData.msgTo == 'dingding'">
                    <el-form-item prop="DINGDING_ALARM" label="报警机器人webhook" :rules="rules">
                        <el-input
                            v-model="formData.DINGDING_ALARM"
                            type="textarea"
                            autosize
                            placeholder="https://oapi.dingtalk.com/robot/send?access_token=xxxx"
                        />
                    </el-form-item>
                    <el-form-item prop="DINGDING_ALARM_SECRET" label="报警机器人密钥" :rules="rules">
                        <el-input v-model="formData.DINGDING_ALARM_SECRET"/>
                    </el-form-item>
                    <el-form-item prop="DINGDING_MSG" :rules="rules">
                        <template #label>
                            通知机器人webhook
                            (<el-text type="warning">可以和报警机器人相同</el-text>)
                        </template>
                        <el-input
                            v-model="formData.DINGDING_MSG"
                            type="textarea"
                            autosize
                            placeholder="https://oapi.dingtalk.com/robot/send?access_token=xxxx"
                        />
                    </el-form-item>
                    <el-form-item prop="DINGDING_MSG_SECRET" :rules="rules">
                        <template #label>
                            通知机器人密钥
                            (<el-text type="warning">可以和报警机器人相同</el-text>)
                        </template>
                        <el-input v-model="formData.DINGDING_MSG_SECRET"/>
                    </el-form-item>
                    <el-form-item prop="serverIp" :rules="rules">
                        <template #label>
                            从钉钉跳转本系统的地址
                            (<el-text type="warning">http://域名或IP:8018 或者 Frp反代到8018端口后填写反代地址</el-text>)
                        </template>
                        <el-input v-model="formData.serverIp" placeholder="http://域名或IP:8018"/>
                    </el-form-item>
                </div>

                <div class="inline-form-items">
                    <el-form-item prop="ALARM_SEND_PIC" label="推送哨兵画面" :rules="rules">
                        <el-select-x v-model="formData.ALARM_SEND_PIC" :options="sendPicOptions" :clearable="false"/>
                    </el-form-item>

                    <el-form-item prop="show_stop_alaram_btn" label="暂停报警推送按钮">
                        <el-switch v-model="formData.show_stop_alaram_btn" active-text="在首页显示暂停报警推送快捷按钮"/>
                    </el-form-item>
                </div>
            </el-card>

            <el-card>
                <template #header>
                    <div class="flex-space-between">
                        <div>有人靠近时推送报警</div>
                        <el-switch v-model="formData.trigger_alarm_person.enable" active-text="开" inactive-text="关"/>
                    </div>
                </template>
                <div v-if="formData.trigger_alarm_person.enable" class="inline-form-items">
                    <el-form-item prop="trigger_alarm_person.reliability" label="AI识别人可信度大于此值时报警" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_person.reliability" :min="0"/>
                    </el-form-item>
                    <el-form-item prop="trigger_alarm_person.shakeG" label="晃动强度(motionGyro 0-750)大于此值视为晃动" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_person.shakeG" :min="0" :max="750"/>
                    </el-form-item>
                    <el-form-item prop="trigger_alarm_person.vibrateGyro" label="振动强度(motionG 0-65530)大于此值视为振动" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_person.vibrateGyro" :min="0" :max="65530"/>
                    </el-form-item>
                    <el-form-item v-if="formData.trigger_alarm_person.enable" prop="trigger_alarm_person.min" label="最小报警间隔(毫秒)" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_person.min" :min="1000" :step="1000"/>
                    </el-form-item>
                </div>
                <div v-if="formData.trigger_alarm_person.enable" class="inline-form-items">
                    <el-form-item v-if="formData.trigger_alarm_person.enable" prop="trigger_alarm_person.title" label="推送信息标题" :rules="rules">
                        <el-input v-model="formData.trigger_alarm_person.title"/>
                    </el-form-item>
                    <el-form-item v-if="formData.trigger_alarm_person.enable" prop="trigger_alarm_person.text" label="推送文字内容" :rules="rules">
                        <el-input v-model="formData.trigger_alarm_person.text" type="textarea" :rows="2" resize="none"/>
                    </el-form-item>
                </div>
            </el-card>

            <el-card>
                <template #header>
                    <div class="flex-space-between">
                        <div>有车经过时推送报警</div>
                        <el-switch v-model="formData.trigger_alarm_car.enable" active-text="开" inactive-text="关"/>
                    </div>
                </template>
                <div v-if="formData.trigger_alarm_car.enable" class="inline-form-items">
                    <el-form-item prop="trigger_alarm_car.reliability" label="AI识别车可信度大于此值时报警" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_car.reliability" :min="0"/>
                    </el-form-item>
                    <el-form-item prop="trigger_alarm_car.shakeG" label="晃动强度(motionGyro 0-750)大于此值视为晃动" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_car.shakeG" :min="0" :max="750"/>
                    </el-form-item>
                    <el-form-item prop="trigger_alarm_car.vibrateGyro" label="振动强度(motionG 0-65530)大于此值视为振动" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_car.vibrateGyro" :min="0" :max="65530"/>
                    </el-form-item>
                    <el-form-item v-if="formData.trigger_alarm_car.enable" prop="trigger_alarm_car.min" label="最小报警间隔(毫秒)" :rules="rules">
                        <el-input-number v-model="formData.trigger_alarm_car.min" :min="1000" :step="1000"/>
                    </el-form-item>
                </div>
                <div v-if="formData.trigger_alarm_car.enable" class="inline-form-items">
                    <el-form-item v-if="formData.trigger_alarm_car.enable" prop="trigger_alarm_car.title" label="推送信息标题" :rules="rules">
                        <el-input v-model="formData.trigger_alarm_car.title"/>
                    </el-form-item>
                    <el-form-item v-if="formData.trigger_alarm_car.enable" prop="trigger_alarm_car.text" label="推送文字内容" :rules="rules">
                        <el-input v-model="formData.trigger_alarm_car.text" type="textarea" :rows="2" resize="none"/>
                    </el-form-item>
                </div>
            </el-card>

            <div style="margin-bottom: 20px">
                <el-text tag="div">
                如你选择"有人靠近时推送报警"或"有车经过时推送报警"，系统将在迪加中添加以Termux开头的自动化配置，配置内容仅在车机迪加APP中可见。<br/>晃动/振动强度阈值同时用于哨兵视频"晃动/振动"筛选的灵敏度（晃动=motionGyro、振动=motionG，大于阈值即筛出）。<br/>迪加自动化仅支持AI人/车触发，晃动/振动推送需在车机迪加APP中配置哨兵震动报警自动化（调用 alarm.php?aiType=4/5 推送）。<br/>
                    如要手动添加迪加自动化配置请参考以下示例：<br/>
                </el-text>
            </div>
            <el-collapse style="margin-bottom: 30px">
                <el-collapse-item title="有人靠近报警示例" name="1">
                    <el-text tag="div">触发选项: AI识别人可信度</el-text>
                    <el-text tag="div">抑制: 10000毫秒</el-text>
                    <el-text tag="div">条件: AI识别人可信度 >= 30</el-text>
                    <el-text tag="div">条件: 远程锁车状态: 锁定</el-text>
                    <el-text tag="div">
                        满足执行:<br/><el-text type="primary">{{ cmd.person }}</el-text>
                    </el-text>
                </el-collapse-item>
                <el-collapse-item title="有车经过报警示例" name="2">
                    <el-text tag="div">触发选项: AI识别车可信度</el-text>
                    <el-text tag="div">抑制: 10000毫秒</el-text>
                    <el-text tag="div">条件: AI识别车可信度 >= 30</el-text>
                    <el-text tag="div">条件: 远程锁车状态 锁定</el-text>
                    <el-text tag="div">
                        满足执行:<br/><el-text type="primary">{{ cmd.car }}</el-text>
                    </el-text>
                </el-collapse-item>
                <el-collapse-item title="一般信息推送示例" name="3">
                    <el-text tag="div">以下内容可填写在远程小迪或自动化命令中执行(逗号%2C, 换行\n):</el-text>
                    <el-text tag="div" type="primary">{{ cmd.msg }}</el-text>
                </el-collapse-item>
            </el-collapse>

        </div>
    </el-form>


    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
.el-card {
    margin-bottom: 30px;
}
.tooltip {
    color: orangered;
    cursor: pointer;
}
</style>