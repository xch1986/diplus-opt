<script setup>
const fbUrl = Vue.ref('');

const getFbUrl = async () => {
    const reg = /(^127\.)|(^192\.168\.)|(^10\.)|(^172\.1[6-9]\.)|(^172\.2[0-9]\.)|(^172\.3[0-1]\.)|(^::1$)|(^[fF][cCdD])/;
    let url = location.protocol + '//' + location.hostname + ':18811';
    if (!reg.test(location.hostname)) {
        try {
            const res = await axios({
                url: 'api/index.php',
                method: 'get'
            });
            if (res.data.data?.filebrowser_url) {
                url = res.data.data.filebrowser_url;
            }
        } catch (e) {}
    }
    fbUrl.value = url;
};
getFbUrl();
</script>

<template>
    <iframe v-if="fbUrl" :src="fbUrl" width="100%" height="900px" style="border: none"></iframe>
    <el-text v-else type="info">正在获取 File Browser 地址…</el-text>
</template>

<style scoped>
/* 手机端: iframe按视口高度自适应+顶格, 让FileBrowser登录卡片视觉上移 */
@media screen and (max-width: 767px) {
    iframe {
        height: calc(100vh - 68px) !important;
        margin-top: -10px;
        margin-left: -10px;
        margin-right: -10px;
        width: calc(100% + 20px);
    }
}
</style>
