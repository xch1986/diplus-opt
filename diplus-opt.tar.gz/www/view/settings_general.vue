<script setup>
import { SSE } from '/includes/sse.js'; // 服务器向浏览器持续推送信息
import elSelectX from '/includes/vue-components/el-select-x.vue';
import sortable from '/includes/vue-components/sortable/sortable.vue';

const formData = Vue.ref({});
const updateInfo = Vue.ref({});
const getUpdate = async () => {
    const res = await axios({
        url: 'api/settings_update.php',
        method: 'get',
        params: {
            action: 'getData'
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    updateInfo.value = res.data.data;
}
const getData = async () => {
    const res = await axios({
        url: 'api/settings_general.php',
        method: 'get',
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
    getUpdate();
}
getData();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }
    const res = await axios({
        url: 'api/settings_general.php',
        method: 'post',
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}
const loading = Vue.ref({
    update: false,
    upgradePackages: false
});
const msg = Vue.ref('');
const progress = Vue.ref('');
const update = async () => {
    let res = await ElementPlus.ElMessageBox.confirm(
            `<div>
                ${updateInfo.value.latest_update.replaceAll('\n', '<br/>')}
            </div>
            <br/>
            <div>确定要更新本系统到 ${updateInfo.value.latest_version} 吗？</div>`,
            `最新版本 ${updateInfo.value.latest_version}`,
            {
                dangerouslyUseHTMLString: true,
            }
        ).catch(() => {});
	if (res != 'confirm') return;

    loading.value.update = true;
    const evtSource = new SSE('api/settings_update.php?action=update', {
        headers: { 'Content-Type': 'application/json' },
        method: 'GET',
        payload: {}
    });
    evtSource.onmessage = (e) => {
        if (e.data.length == 0) return;
        let res = JSON.parse(e.data);
        if (res.status < 0) {
            loading.value.update = false;
            msg.value = `<span color='orangered'>${res.data.msg}</span>`;
            return;
        }
        progress.value = res.data.progress;
        msg.value = res.data.msg;
        if (res.status == 999) {
            loading.value.update = false;
            getData();
        }
    };
}
const upgradePackages = async () => {
    let res = await ElementPlus.ElMessageBox.confirm(
        '即将检查Termux系统软件包(含ffmpeg/nginx/php/frp等)是否有新版本，如有将自动更新，是否继续？'
    ).catch(() => {});
	if (res != 'confirm') return;

    loading.value.upgradePackages = true;
    res = await axios({
        url: 'api/settings_update.php',
        method: 'get',
        params: {
            action: 'upgradePackages'
        }
    });
    loading.value.upgradePackages = false;
    if (res.data.success == -1) {
        gotoLogin();
    }
    msg.value = res.data.msg;
    if (res.data.success == 1) {
        ElementPlus.ElMessage.success(res.data.message);
    } else {
        ElementPlus.ElMessage.error(res.data.message);
    }
}
const restart = async () => {
    let res = await ElementPlus.ElMessageBox.confirm(
            "即将重启Termux，重启后会有几秒钟无响应，请稍后刷新页面查看最新信息。是否继续？",
        ).catch(() => {});
	if (res != 'confirm') return;
    
    res = await axios({
        url: 'api/settings_general.php',
        method: 'get',
        params: {
            action: 'restart'
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
}
const addCustomDir = () => {
    const row = {
        uid: uid(),
        name: '',
        path: ''
    }
    if (!formData.value.custom_video_dirs || formData.value.custom_video_dirs.length == 0) {
        formData.value.custom_video_dirs = [];
    }
    formData.value.custom_video_dirs.push(row);
}
const deleteCustomDir = (index) => {
    formData.value.custom_video_dirs.splice(index, 1);
}
</script>

<template>
    <div class="tab-head">
        <div class="tab-head-title">通用设置</div>
    </div>

    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <div class="inline-form-items">
            <el-form-item prop="USER_ID" label="系统用户名" :rules="rules">
                <el-input v-model="formData.USER_ID"/>
            </el-form-item>
            <el-form-item prop="USER_PASSWORD" label="系统密码" :rules="rules">
                <el-input v-model="formData.USER_PASSWORD"/>
            </el-form-item>
        </div>
        <div class="inline-form-items">
            <el-form-item prop="DIPLUS_AUTH">
                <template #label>
                    迪加API验证凭据
                    <el-tooltip placement="top-start" content="如果迪加设置了验证凭据请复制到这里, 否则无法获取迪加视频">
                        <span class="iconfont icon-question-circle tooltip"></span>
                    </el-tooltip>
                </template>
                <el-input v-model="formData.DIPLUS_AUTH"/>
            </el-form-item>
            <el-form-item prop="filebrowser_url">
                <template #label>
                    首页FileBrowser跳转地址
                    <el-tooltip placement="top-start" content="如用Frp反代到18811端口请填写反代地址，其它情况留空">
                        <span class="iconfont icon-question-circle tooltip"></span>
                    </el-tooltip>
                </template>
                <el-input v-model="formData.filebrowser_url" placeholder="http://域名或IP:18811"/>
            </el-form-item>
        </div>

        <div class="inline-form-items">
            <el-form-item class="gi-cover" prop="cover_filename">
                <template #label>
                    首页图片
                    <el-tooltip placement="top-start" content="可用FileBrowser上传图片到Termux/www/media文件夹，此图片将用作首页封面和默认缩略图">
                        <span class="iconfont icon-question-circle tooltip"></span>
                    </el-tooltip>
                </template>
                <el-select-x v-model="formData.cover_filename" :options="formData.img_files" :clearable="false"/>
            </el-form-item>
            <el-form-item class="gi-bright" prop="video_brightness" :rules="rules">
                <template #label>
                    哨兵视频亮度自动调节最大值
                    <el-tooltip placement="top-start" content="设为0禁止自动调节">
                        <span class="iconfont icon-question-circle tooltip"></span>
                    </el-tooltip>
                </template>
                <el-input-number v-model="formData.video_brightness" :min="0" :max="150"/>
            </el-form-item>
            <el-form-item class="gi-clean" prop="days_clean_screen_record">
                <template #label>
                    自动清理几天前的迪加录屏视频
                    <el-tooltip placement="top-start" content="设为0禁用清理">
                        <span class="iconfont icon-question-circle tooltip"></span>
                    </el-tooltip>
                </template>
                <el-input-number v-model="formData.days_clean_screen_record" :min="0"/>
            </el-form-item>
            <div class="custom-dir gi-custom">
            <el-text tag="div" class="flex-flex-start" style="margin-bottom: 10px">
            自定义视频文件夹
            <el-button type="success" plain size="small" @click="addCustomDir">+ 添加文件夹</el-button>
        </el-text>

        <sortable v-model="formData.custom_video_dirs" handle=".handle" class="container">
            <el-card v-for="(row, index) in formData.custom_video_dirs" :key="row.uid">
                <div class="el-card-toolbar">
                    <el-button text type="primary" size="small" class="handle">
                        <span class="iconfont icon-drag"></span>
                    </el-button>
                    <el-button text type="danger" size="small" @click="deleteCustomDir(index)">
                        <span class="iconfont icon-close-circle"></span>
                    </el-button>
                </div>
                
                <el-form-item label="视频类别/名称" :prop="`custom_video_dirs[${index}].name`" :rules="rules" class="handle">
                    <el-input v-model="row.name"/>
                </el-form-item>
                <el-form-item label="视频文件夹路径" :prop="`custom_video_dirs[${index}].path`" :rules="rules">
                    <el-input v-model="row.path"/>
                </el-form-item>
            </el-card>
        </sortable>
            </div>
            <el-form-item class="gi-thumb" prop="videolist_show_snapshot">
                <template #label>
                    视频缩略图
                    <el-tooltip placement="top-start" content="如列表加载慢可关闭此项">
                        <span class="iconfont icon-question-circle tooltip"></span>
                    </el-tooltip>
                </template>
                <el-switch v-model="formData.videolist_show_snapshot" active-text="在视频列表中显示缩略图"/>
            </el-form-item>
            <el-form-item class="gi-move" prop="move_files_to_sd">
                <template #label>
                    移动视频文件
                    <el-tooltip placement="top-start" content="每次熄火几分钟后开始移动视频">
                        <span class="iconfont icon-question-circle tooltip"></span>
                    </el-tooltip>
                </template>
                <el-switch v-model="formData.move_files_to_sd" active-text="自动将内部存储的迪加哨兵/记录仪视频移动到SD卡"/>
            </el-form-item>
            <el-form-item class="gi-usb" label="USB常通电">
                <el-switch v-model="formData.usb_on"/>
            </el-form-item>
        </div><div class="button-bar">
            <el-button type="danger" @click="restart">重启系统</el-button>
            <el-button type="success" v-loading="loading.upgradePackages" @click="upgradePackages">
                更新软件包
            </el-button>
            <el-button v-if="updateInfo?.latest_version" type="warning" v-loading="loading.update" @click="update">
                更新系统
            </el-button>
            <el-text tag="div">系统版本: {{ formData.version }}</el-text>
            <el-text tag="div">最新版本: {{ updateInfo?.latest_version }}</el-text>
        </div>

        <el-text tag="div" v-html="msg" style="max-height: 400px;overflow: auto;"></el-text>
        <el-progress v-if="loading.update && progress" :percentage="progress"/>
    </el-form>

    <div style="text-align: right">
        <el-link type="primary" target="_blank" href="https://github.com/cnjackchen/diplus-www">
            <span class="iconfont icon-finger-right"></span> 项目主页
        </el-link>
    </div>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
.container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 10px;
    width: 100%;
    margin-bottom: 40px;
}
.container .el-card {
    position: relative;
}
.el-card-toolbar {
    position: absolute;
    top: 10px;
    right: 10px;
    display: flex;
    gap: 10px
}
.el-card-toolbar .iconfont {
    cursor: pointer;
}
.tooltip {
    color: orangered;
    cursor: pointer;
}

/* 通用设置: 电脑两列整齐配对 + 手机一列按分组排序 */
.inline-form-items {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
    gap: 8px 24px;
}
/* 电脑两列: 按截图排布(首页图片|视频缩略图, 亮度|移动视频, 自动清理|USB, 自定义文件夹最后全宽) */
.gi-cover  { grid-column: 1; grid-row: 1; }
.gi-thumb  { grid-column: 2; grid-row: 1; }
.gi-bright { grid-column: 1; grid-row: 2; }
.gi-move   { grid-column: 2; grid-row: 2; }
.gi-clean  { grid-column: 1; grid-row: 3; }
.gi-usb    { grid-column: 2; grid-row: 3; }
.gi-custom { grid-column: 1 / -1; grid-row: 4; }
.custom-dir { width: 100%; }
@media (max-width: 767px) {
    .inline-form-items {
        grid-template-columns: 1fr !important;
    }
    /* 缩小竖向行距, 手机端更紧凑 */
    .inline-form-items .el-form-item {
        margin-bottom: 6px !important;
    }
    /* 清除电脑端显式定位, 只保留顺序 */
    .gi-cover, .gi-bright, .gi-clean, .gi-thumb, .gi-move, .gi-usb, .gi-custom {
        grid-column: auto !important;
        grid-row: auto !important;
    }
    /* 手机一列: 按分组顺序(亮度/自动清理/自定义在上, 视频缩略图/移动/USB在下) */
    .gi-cover  { order: 1; }
    .gi-bright { order: 2; }
    .gi-clean  { order: 3; }
    .gi-custom { order: 4; }
    .gi-thumb  { order: 5; }
    .gi-move   { order: 6; }
    .gi-usb    { order: 7; }
}
</style>