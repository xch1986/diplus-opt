<?php
function getEvents($startTime, $labels) {
    $returnData = [
        'person' => [],
        'car' => []
    ];
    if (!$startTime || !$labels) {
        return $returnData;
    }
    foreach ($labels as $row) {
        foreach ($row['results'] as $result) {
            $timeOffsetMS = floor(($row['timeMS'] - $startTime) / 1000) * 1000; // 时间偏移量，精确到秒
            $timeOffsetMS = max(0, $timeOffsetMS);
            if ($result['className'] == 'person' && !in_array($timeOffsetMS, $returnData['person'])) {
                $returnData['person'][] = $timeOffsetMS;
            } else if ($result['className'] == 'car' && !in_array($timeOffsetMS, $returnData['car'])) {
                $returnData['car'][] = $timeOffsetMS;
            }
        }
    }
    return $returnData;
}


// 查找外插的SD卡或者U盘路径
function getMountedStorage() {
    $output = shell_exec('df -h');
    $lines = explode("\n", trim($output));
    $paths = ['/storage/emulated/0'];
    
    foreach ($lines as $line) {
        if (preg_match('/(?:\/storage|\/mnt|\/media|usb)\/\w{4}-\w{4}/i', $line, $matches)) {
            $paths[] = $matches[0];
        }
    }
    return array_unique($paths);
}


// 从mp4中提取封面，依赖ffmpeg
// 将-ss放在-i之前并结合-c copy或-to参数，可以显著提高从大偏移量截取视频的效率
function getVideoCover($videoFile, $width = 640, $offset = 0) {
    $end = $offset + 1;
    $ffmpeg = '/data/data/com.termux/files/usr/bin/ffmpeg';
    $command = "$ffmpeg -loglevel quiet -ss $offset -i \"$videoFile\" -to $end";
    $command .= " -vf \"scale=$width:-1\" -vframes 1 -f image2pipe -vcodec mjpeg - | base64";
    $ret = exec($command, $output);
    if ($ret === false || !$output) {
        return '';
    }
    return implode('', $output);
}

// 重启Termux
function restart_termux() {
    putenv('PATH=/data/data/com.termux/files/usr/bin:' . getenv('PATH'));
    $file_path = "/storage/emulated/0/Termux/restart.sh";
    $contents = "#!/bin/bash\n";
    $contents .= "sleep 1\n";
    $contents .= "am force-stop com.termux\n";
    $contents .= "sleep 2\n";
    $contents .= "am start -n com.termux/.HomeActivity\n";
    file_put_contents($file_path, $contents);

    $adb_server = "localhost:5555";
    exec("adb connect $adb_server");
    exec("adb -s $adb_server shell \"nohup sh $file_path > /dev/null 2>&1 &\"");
    exec("adb disconnect $adb_server");
    return true;
}
?>