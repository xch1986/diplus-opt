<?php

header('Content-type: application/json; charset=utf-8');

header("Cache-Control: no-cache");

require_once '../includes/phpshare.php';

require_once '../includes/db.php';

require_once '../includes/diplus_config.php';



$ajson = ['success' => 0, 'message' => '', 'data' => []];

$login = login(false);

if (!$login) {

    $ajson['success'] = -1;

    $ajson['message'] = '未登录系统。';

    returnJson($ajson);

}



$conn = db_conn();



$post = json_decode_x(file_get_contents('php://input'));

if ($post) {

    // writeSettings($conn, 'global', 'diplusUseWechat', $post['diplusUseWechat']);

    writeSettings($conn, 'global', 'msgTo', $post['msgTo']);

    writeSettings($conn, 'global', 'serverIp', $post['serverIp']);

    

    $WETCHAT_ALARM = str_replace(["\r", "\n"], '', $post['WECHAT_ALARM']);

    writeSettings($conn, 'global', 'WECHAT_ALARM', $WETCHAT_ALARM);

    $WECHAT_MSG = str_replace(["\r", "\n"], '', $post['WECHAT_MSG']);

    writeSettings($conn, 'global', 'WECHAT_MSG', $WECHAT_MSG);

    $ALARM_SEND_PIC = $post['ALARM_SEND_PIC'] ?: 0;

    writeSettings($conn, 'global', 'ALARM_SEND_PIC', $ALARM_SEND_PIC);

    writeSettings($conn, 'global', 'show_stop_alaram_btn', $post['show_stop_alaram_btn'] ?: 0);



    $DINGDING_ALARM = str_replace(["\r", "\n"], '', $post['DINGDING_ALARM']);

    writeSettings($conn, 'global', 'DINGDING_ALARM', $DINGDING_ALARM);

    writeSettings($conn, 'global', 'DINGDING_ALARM_SECRET', $post['DINGDING_ALARM_SECRET']);

    $DINGDING_MSG = str_replace(["\r", "\n"], '', $post['DINGDING_MSG']);

    writeSettings($conn, 'global', 'DINGDING_MSG', $DINGDING_MSG);

    writeSettings($conn, 'global', 'DINGDING_MSG_SECRET', $post['DINGDING_MSG_SECRET']);



    $DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');

    $trigger_alarm_person = $post['trigger_alarm_person'];

    if ($trigger_alarm_person['enable']) {

        $res = setTriggerAlarmPerson($trigger_alarm_person, $DIPLUS_AUTH);

        if (!$res) {

            $ajson['message'] .= '设置有人靠近报警自动化失败！';

        }

    } else {

        $res = enableTrigger('Termux-有人靠近报警', false, $DIPLUS_AUTH);

        if (!$res) {

            $ajson['message'] .= '关闭有人靠近报警自动化失败！';

        }

    }

    writeSettings($conn, 'diplus', 'trigger_alarm_person', json_encode_x($trigger_alarm_person));



    $trigger_alarm_car = $post['trigger_alarm_car'];

    if ($trigger_alarm_car['enable']) {

        $res = setTriggerAlarmCar($trigger_alarm_car, $DIPLUS_AUTH);

        if (!$res) {

            $ajson['message'] .= '设置有车经过报警自动化失败！';

        }

    } else {

        $res = enableTrigger('Termux-有车经过报警', false, $DIPLUS_AUTH);

        if (!$res) {

            $ajson['message'] .= '关闭有车经过报警自动化失败！';

        }

    }

    writeSettings($conn, 'diplus', 'trigger_alarm_car', json_encode_x($trigger_alarm_car));

    // 同步推送晃动/振动阈值到哨兵筛选(config_M.dat: AlarmGyro=晃动, AlarmGSensor=振动)
    // 取有人靠近(trigger_alarm_person)的阈值作为全局, 使哨兵筛选/推送/车机app三者一致
    $syncShake = (int)($trigger_alarm_person['shakeG'] ?? 0);
    $syncVibrate = (int)($trigger_alarm_person['vibrateGyro'] ?? 0);
    if ($syncShake > 0 || $syncVibrate > 0) {
        $cfgFile = '/storage/emulated/0/vandiplus/config_M.dat';
        $cfgContent = @file_get_contents($cfgFile);
        if ($cfgContent !== false) {
            if ($syncShake > 0 && preg_match('/AlarmGyro=(\w+)/', $cfgContent)) {
                $cfgContent = preg_replace('/AlarmGyro=(\w+)/', 'AlarmGyro=' . $syncShake, $cfgContent, 1);
            }
            if ($syncVibrate > 0 && preg_match('/AlarmGSensor=(\w+)/', $cfgContent)) {
                $cfgContent = preg_replace('/AlarmGSensor=(\w+)/', 'AlarmGSensor=' . $syncVibrate, $cfgContent, 1);
            }
            @file_put_contents($cfgFile, $cfgContent);
        }
    }




    $trigger_alarm_shake = $post['trigger_alarm_shake'] ?: [];

    writeSettings($conn, 'diplus', 'trigger_alarm_shake', json_encode_x($trigger_alarm_shake));

    $trigger_alarm_vibrate = $post['trigger_alarm_vibrate'] ?: [];

    writeSettings($conn, 'diplus', 'trigger_alarm_vibrate', json_encode_x($trigger_alarm_vibrate));



	$ajson['message'] = '数据保存成功！';

    $ajson['success'] = 1;

    returnJson($ajson);

}





$returnData = [];

// $returnData['diplusUseWechat'] = readSettings($conn, 'global', 'diplusUseWechat') ? true : false;

$returnData['msgTo'] = readSettings($conn, 'global', 'msgTo');

$returnData['serverIp'] = readSettings($conn, 'global', 'serverIp');

$returnData['WECHAT_ALARM'] = readSettings($conn, 'global', 'WECHAT_ALARM');

$returnData['WECHAT_MSG'] = readSettings($conn, 'global', 'WECHAT_MSG');

$ALARM_SEND_PIC = readSettings($conn, 'global', 'ALARM_SEND_PIC');

$returnData['ALARM_SEND_PIC'] = is_numeric($ALARM_SEND_PIC) ? $ALARM_SEND_PIC * 1 : 1;

$show_stop_alaram_btn = readSettings($conn, 'global', 'show_stop_alaram_btn');

$returnData['show_stop_alaram_btn'] = $show_stop_alaram_btn == '' || $show_stop_alaram_btn == 1;



$returnData['DINGDING_ALARM'] = readSettings($conn, 'global', 'DINGDING_ALARM');

$returnData['DINGDING_ALARM_SECRET'] = readSettings($conn, 'global', 'DINGDING_ALARM_SECRET');

$returnData['DINGDING_MSG'] = readSettings($conn, 'global', 'DINGDING_MSG');

$returnData['DINGDING_MSG_SECRET'] = readSettings($conn, 'global', 'DINGDING_MSG_SECRET');



$trigger_alarm_person = readSettings($conn, 'diplus', 'trigger_alarm_person');

if ($trigger_alarm_person == '' || $trigger_alarm_person == 0 || $trigger_alarm_person == 1) {

    $returnData['trigger_alarm_person'] = [

        'enable' => $trigger_alarm_person == 1,

        'reliability' => 30,

        'min' => 10000,

        'title' => '比亚迪-有人靠近',

        'text' => '有人靠近车辆(可信度{AI识别人可信度})',

        'shakeG' => 10,

        'vibrateGyro' => 10

    ];

} else {

    $returnData['trigger_alarm_person'] = json_decode_x($trigger_alarm_person);

}



$trigger_alarm_car = readSettings($conn, 'diplus', 'trigger_alarm_car');

if ($trigger_alarm_car == '' || $trigger_alarm_car == 0 || $trigger_alarm_car == 1) {

    $returnData['trigger_alarm_car'] = [

        'enable' => $trigger_alarm_car == 1,

        'reliability' => 30,

        'min' => 10000,

        'title' => '比亚迪-有车经过',

        'text' => '有车经过车辆(可信度{AI识别车可信度})',

        'shakeG' => 10,

        'vibrateGyro' => 10

    ];

} else {

    $returnData['trigger_alarm_car'] = json_decode_x($trigger_alarm_car);

}



$returnData['trigger_alarm_shake'] = json_decode_x(readSettings($conn, 'diplus', 'trigger_alarm_shake'));

$returnData['trigger_alarm_vibrate'] = json_decode_x(readSettings($conn, 'diplus', 'trigger_alarm_vibrate'));



$ajson['data'] = $returnData;

$ajson['success'] = 1;

returnJson($ajson);

?>