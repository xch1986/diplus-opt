<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';
require_once '../includes/wechat.php';
require_once '../includes/dingding.php';
require_once '../includes/image.php';
require_once '../includes/share.php';

ignore_user_abort(true); // 防止客户端超时退出导致程序中断
set_time_limit(600);
$ajson = ['success' => 0, 'message' => '', 'data' => []];
@mkdir(dirname('/data/data/com.termux/files/home/alarm_debug.txt'), 0777, true);
@file_put_contents('/data/data/com.termux/files/home/alarm_debug.txt',
    date('Y-m-d H:i:s')." ANY_CALL host=".($_SERVER['HTTP_HOST'] ?? '?')." get=".($_SERVER['QUERY_STRING'] ?? '')."\n", FILE_APPEND);


// 非本地访问需验证身份
if ($_SERVER['HTTP_HOST'] != 'localhost:8018' && $_SERVER['HTTP_HOST'] != '127.0.0.1:8018') {
	$login = login(false);
	if (!$login) {
		$ajson['success'] = -1;
		$ajson['message'] = '未登录系统。';
		returnJson($ajson);
	}
}

$conn = db_conn();
$msgTo = readSettings($conn, 'global', 'msgTo');
if (!in_array($msgTo, ['wechat', 'dingding'])) {
	$ajson['message'] = "发送信息失败！未启用接收报警信息。";
	returnJson($ajson);
}

$no_alarm_before = (int)readSettings($conn, 'global', 'no_alarm_before');
if (time() * 1000 < $no_alarm_before) {
	$ajson['message'] = "暂停报警时间未到，不推送报警信息。";
	$ajson['success'] = 1;
	returnJson($ajson);
}

$home = $_ENV['HOME'];
$aiType = $_POST['aiType'] ?? 1; // 0-忽略AI检测, 1-person, 2-car, 3-person+car
$title = $_POST['title'] ?? '比亚迪';

// 上次哨兵触发时间戳（13位，格式 1742389518663 或 1.742389518663E12）
$triggerTime = (float)($_POST['triggerTime'] ?? 0);
if (!preg_match('/^\d{13}$/', $triggerTime)) {
	$triggerTime = time() * 1000;
}
$time = date('Y-m-d H:i:s', round($triggerTime / 1000));

// 上次哨兵触发画面, php会把base64中的+解码成空格，这里替换回来
$triggerImg = $_POST['triggerImg'] ?? '';
$triggerImg = str_replace(' ', '+', $triggerImg);

// 上次录像文件开始时间
$videoFileStartTime = $_POST['videoFileStartTime'] ?? 0;
$text = isset($_POST['text']) ? $_POST['text'] : '';
$text = str_replace('\n', "\n", $text);
// 修复: 迪加自动化URL传输text时中文被截断(如"可信度62"后中文丢失), 用db模板+可信度重建完整文本
if (in_array((int)$aiType, [1, 2]) && $text && strpos($text, '晃动') === false) {
    $tplJson = readSettings($conn, 'diplus', $aiType == 1 ? 'trigger_alarm_person' : 'trigger_alarm_car');
    $tpl = json_decode_x($tplJson);
    if (is_array($tpl) && !empty($tpl['text']) && strpos($tpl['text'], '{') !== false) {
        $conf = 0;
        if (preg_match('/可信度(\d+)/', $text, $m)) $conf = (int)$m[1];
        elseif (preg_match('/conf[=:]?(\d+)/i', $text, $m)) $conf = (int)$m[1];
        $rebuilt = str_replace(
            ['{AI识别人可信度}', '{AI识别车可信度}', '{晃动强度}', '{振动强度}'],
            [$conf, $conf, (int)@$tpl['shakeG'], (int)@$tpl['vibrateGyro']],
            $tpl['text']
        );
        if (strpos($rebuilt, '{') === false && $rebuilt) $text = $rebuilt;
    }
}
$content = "$time\n$text";

// 推送逻辑: 有人/有车 且（晃动或振动）才推送 (阈值取车机迪加 config_M.dat AlarmGyro/AlarmGSensor)
$shakeTh = 5;
$vibrateTh = 2;
$cfgFile = '/storage/emulated/0/vandiplus/config_M.dat';
if (file_exists($cfgFile)) {
    $cfgContent = @file_get_contents($cfgFile);
    if (preg_match('/AlarmGyro=(\d+)/', $cfgContent, $m)) $shakeTh = (float)$m[1];
    if (preg_match('/AlarmGSensor=(\d+)/', $cfgContent, $m)) $vibrateTh = (float)$m[1];
}
// 查找该次触发时间对应的哨兵视频, 判断是否伴随晃动/振动
if (in_array((int)$aiType, [1, 2])) {
    $DIPLUS_AUTH0 = readSettings($conn, 'global', 'DIPLUS_AUTH');
    $str_date0 = date('Ymd', strtotime($time));
    $url0 = "http://localhost:8988/api/videoFiles?type=0&dir=$str_date0&auth=".urlencode($DIPLUS_AUTH0);
    $motionOK = null; // null=未找到视频(放行), true=满足, false=不满足
    for ($i = 0; $i < 6; $i++) {
        $res0 = @file_get_contents($url0, false, $context);
        if ($res0) {
            $list0 = json_decode_x($res0);
            if (is_array($list0)) {
                foreach ($list0 as $row0) {
                    if (!isset($row0['startTime'])) continue;
                    $e0 = isset($row0['endTime']) ? $row0['endTime'] : $row0['startTime'];
                    if ($triggerTime >= $row0['startTime'] && $triggerTime <= $e0) {
                        $mG = (float)($row0['motionG'] ?? 0);
                        $mGyro = (float)($row0['motionGyro'] ?? 0);
                        $motionOK = ($mGyro >= $shakeTh) || ($mG >= $vibrateTh); // 晃动=陀螺仪(motionGyro), 振动=加速度(motionG), 与车机一致
                        break 2;
                    }
                }
            }
        }
        if ($i < 5) sleep(2);
    }
    if ($motionOK === false) {
        $ajson['success'] = 1;
        $ajson['message'] = ($aiType == 1 ? "有人" : "有车") . "但晃动/振动不足(motionG<{$shakeTh}且motionGyro<{$vibrateTh}),不推送";
        returnJson($ajson);
    }
}

// 记录车辆位置等信息
// $url = "http://localhost:8018/api/save_driving_data.php?timestamp=$triggerTime";
// $context = stream_context_create([
// 	'http' => [
// 		'timeout' => 5
// 	]
// ]);
// $res = @file_get_contents($url, false, $context);
// if (!$res) {
// 	$ajson['message'] .= "记录车辆位置信息失败！$res";
// }
// $resData = json_decode_x($res);
// if (@$resData['success'] != 1) {
// 	$ajson['message'] .= "记录车辆位置信息失败！".@$resData['message'];
// }

$ALARM_SEND_PIC = readSettings($conn, 'global', 'ALARM_SEND_PIC') * 1;
$serverIp = readSettings($conn, 'global', 'serverIp');
$video_brightness = readSettings($conn, 'global', 'video_brightness');
$cover_filename = readSettings($conn, 'global', 'cover_filename') ?: 'byd.jpg'; // 默认封面图片
$picUrl = "$serverIp/media/$cover_filename";

// 清理临时文件
$tmpDir = "$home/www/media/tmp";
$files = scandir($tmpDir);
$now = time();
// 删除临时文件夹中5分钟以前的文件
foreach ($files as $file) {
	$filePath = "$tmpDir/$file";
	if (is_file($filePath)) {
		$fileCreationTime = filemtime($filePath);
		if (($now - $fileCreationTime) > 300) {
			unlink($filePath);
		}
	}
}

// 微信/钉钉跳转至哨兵视频的链接
$jumpUrl = "$serverIp/alarm_details.html";
$jumpUrl .= "?time=".urlencode($time);
$jumpUrl .= "&aiType=$aiType";
$jumpUrl .= "&title=".urlencode($title);
$jumpUrl .= "&text=".urlencode($text);

if ($msgTo == 'wechat') {
	$WECHAT_ALARM = readSettings($conn, 'global', 'WECHAT_ALARM');
	if ($ALARM_SEND_PIC == 1 && $triggerImg) {
		$fileName = "cover_".uniqid().".jpg";
		$filePath = "$tmpDir/$fileName";
		file_put_contents($filePath, base64_decode($triggerImg));
		if ($video_brightness) {
			adjustImgBrightness($filePath, $video_brightness);
		}
		$picUrl = "$serverIp/media/tmp/$fileName";
	}

	// 微信news不支持base64图片，markdown不支持在个人微信查看
	$msgData = [
		"msgtype" => "news",
		"news" => [
			"articles" => [
				[
					"title" => $title,
					"description" => str_replace("\n", " ", $content),
					"url" => $jumpUrl,
					"picurl" => $ALARM_SEND_PIC == 1 ? $picUrl : ''
				]
			]
		]
	];
	// DEBUG日志: 记录推送的完整description, 用于排查微信显示不全
@mkdir(dirname('/data/data/com.termux/files/home/alarm_debug.txt'), 0777, true);
@file_put_contents('/data/data/com.termux/files/home/alarm_debug.txt',
    date('Y-m-d H:i:s')." aiType=$aiType title=$title text=[$text] desc=[".
    (isset($msgData['news']['articles'][0]['description']) ? $msgData['news']['articles'][0]['description'] : '').
    "]\n", FILE_APPEND);
$ret = sendToWechatGroup($WECHAT_ALARM, $msgData);
	if ($ret !== true) {
		$ajson['message'] .= "发送信息失败！$ret";
	} else {
		$ajson['success'] = 1;
		$ajson['message'] .= "信息发送成功！";
	}
	if ($ALARM_SEND_PIC == 1) {
		returnJson($ajson);
	}
}


if ($msgTo == 'dingding') {
	$DINGDING_ALARM = readSettings($conn, 'global', 'DINGDING_ALARM');
	$DINGDING_ALARM_SECRET = readSettings($conn, 'global', 'DINGDING_ALARM_SECRET');

	// 钉钉markdown图片地址不支持ipv6，base64图片 + 其他内容总大小不能超过20KB
	$sendText = "";
	if ($ALARM_SEND_PIC == 1) {
		$picUrlBase64 = "";
		if ($triggerImg) {
			$base64 = adjustImgFromBase64($triggerImg, $video_brightness, 15);
			if ($base64) {
				$picUrlBase64 = "data:image/jpeg;base64,$base64";
			}
		}
		// 没封面就用默认图片
		if (!$picUrlBase64) {
			$imageData = file_get_contents("$home/www/media/$cover_filename");
			$base64 = base64_encode($imageData);
			$base64 = adjustImgFromBase64($base64, 0, 15); // 默认图片不需要调亮度，亮度目标值设为0
			$picUrlBase64 = "data:image/jpeg;base64,$base64";
		}
		$sendText .= "![pic]($picUrlBase64)\n\n";
	}
	$content_dingding = str_replace("\n", "\n\n", $content);
	$sendText .= "#### $title\n\n$content_dingding\n\n";
	$sendText .= "[点击查看详情]($jumpUrl)";
	$msgData = [
		"msgtype" => "markdown",
		"markdown" => [
			"title" => $title,
			"text" => $sendText
		]
	];

	$ret = sendToDingdingGroup($DINGDING_ALARM, $DINGDING_ALARM_SECRET, $msgData);
	if ($ret !== true) {
		$ajson['message'] .= "发送信息失败！$ret";
	} else {
		$ajson['success'] = 1;
		$ajson['message'] .= "信息发送成功！";
	}
	if ($ALARM_SEND_PIC == 1) {
		returnJson($ajson);
	}
}

if ($ALARM_SEND_PIC != 2) {
	returnJson($ajson);
}


// 需要推送大图, 关闭连接继续运行
$ajson['message'] .= "待哨兵视频生成后推送图片...";
echo json_encode($ajson, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
fastcgi_finish_request();


// 等待视频生成并截取触发画面
$checkTimes = 60;
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$str_date = date('Ymd', strtotime($time));
$url = "http://localhost:8988/api/videoFiles?type=0&dir=$str_date&auth=".urlencode($DIPLUS_AUTH);
$context = stream_context_create([
	'http' => [
		'timeout' => 5
	]
]);
$videoFile = [];
for ($i = 0; $i < $checkTimes; $i++) {
	sleep(5);
	$res = @file_get_contents($url, false, $context);
	if (!$res) {
		continue;
	}
	// 返回的文件列表是按时间倒序排列的
	$resData = json_decode_x($res);
	foreach ($resData as $row) {
		if ($triggerTime >= $row['startTime'] && $triggerTime <= $row['endTime']) {
			$videoFile = $row;
			break 2;
		}
	}
}

if (!$videoFile) {
	$ajson['message'] = '找不到视频文件，哨兵触发图片未推送！';
	returnJson($ajson);
}
$videoFilePath = base64_decode($videoFile['key']);
$timeOffset = round(($triggerTime - $videoFile['startTime']) / 1000);
if (!file_exists($videoFilePath)) {
	$ajson['message'] = '获取视频文件失败，哨兵触发图片未推送！';
	returnJson($ajson);
}

$imgBase64 = getVideoCover($videoFilePath, 1280, $timeOffset);
$imgBase64 = adjustImgFromBase64($imgBase64, $video_brightness, 1024);
if (!$imgBase64) {
	$ajson['message'] = '获取哨兵触发画面失败，图片未推送！';
	returnJson($ajson);
}
$imgData = base64_decode($imgBase64); // 未编码的图片数据


if ($msgTo == 'wechat') {
	// 单独发图片最大不能超过2M，支持JPG,PNG格式
	// https://developer.work.weixin.qq.com/document/path/91770#%E5%9B%BE%E7%89%87%E7%B1%BB%E5%9E%8B
	$imgMd5 = md5($imgData);
	$msgData = [
		"msgtype" => "image",
		"image" => [
			"base64" => $imgBase64,
			"md5" => $imgMd5
		]
	];
	$ret = sendToWechatGroup($WECHAT_ALARM, $msgData);
	$ajson['message'] .= $ret !== true ? "哨兵画面发送失败！$ret" : "哨兵画面发送成功！";
}

if ($msgTo == 'dingding') {
	// 钉钉发base64图不能超过20KB，这里采用文件链接形式发送高清图片
	$fileName = "cover_".uniqid().".jpg";
	$filePath = "$tmpDir/$fileName";
	file_put_contents($filePath, $imgData);
	$bigPicUrl = "$serverIp/media/tmp/$fileName";

	$sendText = "![pic]($bigPicUrl)\n\n";
	$sendText .= "$time\n\n";
	$sendText .= "[点击查看详情]($jumpUrl)";
	$msgData = [
		"msgtype" => "markdown",
		"markdown" => [
			"title" => $title,
			"text" => $sendText
		]
	];

	$ret = sendToDingdingGroup($DINGDING_ALARM, $DINGDING_ALARM_SECRET, $msgData);
	$ajson['message'] .= $ret !== true ? "哨兵画面发送失败！$ret" : "哨兵画面发送成功！";
}

returnJson($ajson);
?>
