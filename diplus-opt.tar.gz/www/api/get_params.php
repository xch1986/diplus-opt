<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = [
    'success' => 0,
    'message' => '',
    'data' => [
        'preset_params' => [],
        'diparams' => [],
        'maint' => []
    ]
];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取车况数据失败！未登录系统。';
    returnJson($ajson);
}

$conn = db_conn();
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$diplus_params = json_decode_x(readSettings($conn, 'diplus', 'diplus_params'));
$preset_params = json_decode_x(readSettings($conn, 'diplus', 'preset_params'));
$maint = json_decode_x(readSettings($conn, 'global', 'maint'));
if (!$diplus_params && !$preset_params && (!$maint || !@$maint['show_maint'])) {
    $ajson['success'] = 1;
    $ajson['message'] = '没有需要获取的数据！';
    returnJson($ajson);
}

// 预设参数
$aText = [];
if (@$preset_params['show_position'] == true) {
    $aText[] = "location|{位置}";
    $aText[] = "speed|{车速}";
}
if (@$preset_params['tire_pressure']['show'] == true) {
    $aText[] = "tire_pressure_fl|{左前轮气压}";
    $aText[] = "tire_pressure_fr|{右前轮气压}";
    $aText[] = "tire_pressure_rl|{左后轮气压}";
    $aText[] = "tire_pressure_rr|{右后轮气压}";
}
if (!$aText && !$diplus_params) {
    $ajson['message'] = '没有需要获取的数据！';
    returnJson($ajson);
}
if ($aText) {
    $text = implode('|!|', $aText);
    $url = "http://localhost:8988/api/getDiPars";
    $url .= "?text=".urlencode($text);
    $url .= "&auth=".urlencode($DIPLUS_AUTH);
    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);
    $res = json_decode_x(@file_get_contents($url, false, $context));
    if (@$res['success'] && !empty($res['val'])) {
        $d = explode('|!|', $res['val']);
        $data = [];
        foreach ($d as $row) {
            $arr = explode('|', $row, 2);
            if (count($arr) !== 2) {
                continue;
            }
            $data[$arr[0]] = $arr[1];
        }
        if (!empty($data['location'])) {
            $arr = explode(',', $data['location']);
            $data['location'] = [
                'longitude' => (float)$arr[0],
                'latitude' => (float)@$arr[1],
                'bearing' => (float)@$arr[2],
                'altitude' => (float)@$arr[3]
            ];
        }
        $ajson['data']['preset_params'] = $data;
    }
}

// 如果当前车速为0，计算停车时间
if (!empty($ajson['data']['preset_params']['location']) && $ajson['data']['preset_params']['speed'] == 0) {
    $dbPath = '/storage/emulated/0/Termux/db.db';
    $conn1 = db_conn($err, $dbPath);
    // 找最近一条速度不为0的记录
    $sql = "SELECT `timestamp` FROM driving_data WHERE speed > 0 ORDER BY `timestamp` DESC LIMIT 1";
    $timestamp = 0;
    $row = db_query_row($conn1, $sql);
    if ($row) {
        $lastDrive = $row['timestamp'];
        // 找停止行驶之后的第一条停车记录（取最早一条），作为本次停车开始时间
        $sql = "SELECT `timestamp` FROM driving_data WHERE `timestamp` > $lastDrive AND speed = 0 ORDER BY `timestamp` ASC LIMIT 1";
        $row = db_query_row($conn1, $sql);
        if ($row) {
            $timestamp = $row['timestamp'];
        } else {
            // 没有找到停车记录，用最后一次行驶时间作为停车开始时间
            $timestamp = $lastDrive;
        }
    } else { // 没有行驶记录, 取第一条记录
        $sql = "SELECT `timestamp` FROM driving_data LIMIT 1";
        $row = db_query_row($conn1, $sql);
        if ($row) {
            $timestamp = $row['timestamp'];
        }
    }
    if ($timestamp) {
        $ajson['data']['preset_params']['parking_time'] = secondsToTimeString(round((time() - $timestamp / 1000)));
    }
    $conn1 = null;
}


// 自定义参数
$aText = [];
foreach ($diplus_params as $row) {
    if (!isset($row['show']) || $row['show']) {
        $uid = @$row['uid'];
        $name = @$row['name'];
        $label = @$row['label'];
        if (!$uid || !$name || !$label) {
            continue;
        }
        $val_name = $row['dataType'] === 'number' ? "{".$name."}" : "[$name]";
        $aText[] = "$uid|$label|$val_name";
    }
}
if ($aText) {
    $text = implode('|!|', $aText);
    $url = "http://localhost:8988/api/getDiPars";
    $url .= "?text=".urlencode($text);
    $url .= "&auth=".urlencode($DIPLUS_AUTH);
    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);
    $res = json_decode_x(@file_get_contents($url, false, $context));
    if (!$res || $res['success'] !== true || empty($res['val'])) {
        $ajson['message'] = '获取车况数据失败！';
        returnJson($ajson);
    }

    $val = $res['val'];
    $data = explode('|!|', $val);
    foreach ($data as &$row) {
        $arr = explode('|', $row, 3);
        if (count($arr) !== 3) {
            continue;
        }
        $row = [
            'uid' => $arr[0],
            'label' => $arr[1],
            'value' => is_numeric($arr[2]) ? $arr[2] * 1 : $arr[2]
        ];
        $index = arraySearch2D($diplus_params, 'uid', $row['uid']);
        if ($index !== false) {
            $dataType = $diplus_params[$index]['dataType'] ?? 'number';
            $row['name'] = $diplus_params[$index]['name'];
            if ($dataType === 'number' && (@$diplus_params[$index]['save'] || @$diplus_params[$index]['monitor']) ) {
                $row['hasTrend'] = true;
            }
            $factor = $diplus_params[$index]['factor'] ?? 1;
            if ($dataType == 'number' && is_numeric($row['value']) && is_numeric($factor)) {
                $row['precision'] = $diplus_params[$index]['precision'] ?? 0;
                $row['value'] = round($row['value'] * $factor, $row['precision']);
            }
        }
    }
    unset($row);
    $ajson['data']['diparams'] = $data;
}

// 保养提醒
if (@$maint['show_maint']) {
    if (@$maint['month_interval'] && @$maint['lastest_date']) {
        $month_interval = $maint['month_interval'];
        $lastest_date = $maint['lastest_date'];
        $ajson['data']['maint']['next_date'] = date('Y-m-d', strtotime("+$month_interval months", strtotime($lastest_date)));
    }

    if (@$maint['mileage_interval'] && @$maint['lastest_mileage']) {
        $next_mileage = $maint['lastest_mileage'] + $maint['mileage_interval'];
        $dbPath = '/storage/emulated/0/vandiplus/db/van_bm_db';
        $conn2 = db_conn($err, $dbPath);
        $sql = "SELECT mileage_end / 10.0 AS mileage FROM TripInfo ORDER BY time_end DESC LIMIT 1";
        $row = db_query_row($conn2, $sql);
        if ($row) {
            $ajson['data']['maint']['remain_mileage'] = round($next_mileage - $row['mileage']);
        }
    }
}

$ajson['success'] = 1;
$ajson['message'] = "车况数据获取成功！";
returnJson($ajson);


function secondsToTimeString($seconds) {
    $minutes = floor($seconds / 60);
    $seconds %= 60;
    $hours = floor($minutes / 60);
    $minutes %= 60;
    $days = floor($hours / 24);
    $hours %= 24;
    
    $result = [];
    if ($days > 0) {
        $result[] = $days . '天';
    }
    if ($hours > 0) {
        $result[] = $hours . '时';
    }
    // 超过1天不显示分钟数
    if (!$days && $minutes > 0) {
        $result[] = $minutes . '分';
    }

    return implode('', $result);
}
?>
