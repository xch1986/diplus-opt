<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}
$action = @$_GET['action'] ?? '';
if (!$action) {
    $ajson['message'] = '缺少参数';
    returnJson($ajson);
}

// 添加环境变量，否则command -v xxx 等命令不能返回正确结果
putenv('PATH=/data/data/com.termux/files/usr/bin:' . getenv('PATH'));
$home = $_ENV['HOME'];

$conn = db_conn();

$post = json_decode_x(file_get_contents('php://input'));
if ($action == 'saveData' && $post) {
    writeSettings($conn, 'openlist', 'openlistOn', $post['openlistOn'] ?: 0);

    $ajson['message'] = '数据保存成功！';
    $ajson['success'] = 1;
    returnJson($ajson);
}


if ($action == 'getData') {
    $returnData = [];
    $returnData['openlistOn'] = readSettings($conn, 'openlist', 'openlistOn') == 1;
    $bin_path = '/data/data/com.termux/files/usr/bin/openlist';
    $returnData['openlist_installed'] = file_exists($bin_path);
    $returnData['openlist_version'] = '';
    if (file_exists($bin_path)) {
        exec("$bin_path version 2>&1 | head -1", $output);
        if ($output) {
            $returnData['openlist_version'] = trim(end($output));
        }
    }
    unset($output);
    exec('pgrep -f "openlist server"', $output);
    $returnData['openlist_is_running'] = count($output) > 1;

    $ajson['data'] = $returnData;
    $ajson['success'] = 1;
    returnJson($ajson);
}


if ($action == 'stop' || $action == 'restart') {
    exec('pgrep -f "openlist server"', $output);
    if ($output && count($output) > 1) {
        unset($output);
        exec('pkill -f "openlist server"', $output);
        if ($output) {
            $ajson['message'] = "停止 openlist 进程时发生错误。".implode("\n", $output);
            returnJson($ajson);
        }
    }
    $ajson['data']['openlist_is_running'] = false;
    if ($action == 'stop') {
        $ajson['message'] = "openlist 已停止运行";
        $ajson['success'] = 1;
        returnJson($ajson);
    }
}


if ($action == 'start' || $action == 'restart') {
    $script_path = "$home/boot/openlist.sh";
    if (!file_exists($script_path)) {
        $ajson['message'] = "openlist 启动失败，启动脚本未找到";
        $ajson['data']['openlist_is_running'] = false;
        returnJson($ajson);
    }
    exec("bash $script_path", $output, $return_var);
    if ($return_var !== 0) {
        $ajson['message'] = "启动 openlist 时发生错误";
        $ajson['data']['openlist_is_running'] = false;
        returnJson($ajson);
    }

    unset($output);
    exec('pgrep -f "openlist server"', $output);
    if (!$output || count($output) < 2) {
        $ajson['message'] = "openlist 启动失败";
        $ajson['data']['openlist_is_running'] = false;
        returnJson($ajson);
    }

    $ajson['data']['openlist_is_running'] = true;
    $ajson['message'] = "openlist 启动成功";
    $ajson['success'] = 1;
    returnJson($ajson);
}

$ajson['message'] = "执行成功";
$ajson['success'] = 1;
returnJson($ajson);
?>
