<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$action = $_GET['action'] ?? 'getData';
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}

$home = $_ENV['HOME'];

if ($action == 'restart') {
    restart_termux();
    $ajson['success'] = 1;
    $ajson['message'] = '正在重启，请稍后刷新页面查看最新信息 ...';
    returnJson($ajson);
}


$conn = db_conn();

$post = json_decode_x(file_get_contents('php://input'));
if ($post) {
    if (!$post['USER_ID'] || !$post['USER_PASSWORD']) {
        $ajson['message'] = "用户名/密码不能为空！";
		returnJson($ajson);
    }

    writeSettings($conn, 'global', 'USER_ID', $post['USER_ID']);
    writeSettings($conn, 'global', 'USER_PASSWORD', $post['USER_PASSWORD']);
    writeSettings($conn, 'global', 'DIPLUS_AUTH', $post['DIPLUS_AUTH']);
    writeSettings($conn, 'global', 'filebrowser_url', $post['filebrowser_url']);
    writeSettings($conn, 'global', 'cover_filename', $post['cover_filename'] ?: 'byd.jpg');
    writeSettings($conn, 'global', 'videolist_show_snapshot', $post['videolist_show_snapshot'] ?: 0);
    writeSettings($conn, 'global', 'video_brightness', (int) $post['video_brightness']);
    writeSettings($conn, 'global', 'move_files_to_sd', $post['move_files_to_sd'] ?: 0);
    writeSettings($conn, 'global', 'days_clean_screen_record', $post['days_clean_screen_record'] ?: 0);
    $str = json_encode_x($post['custom_video_dirs']);
    writeSettings($conn, 'global', 'custom_video_dirs', $str);
    writeSettings($conn, 'global', 'fuel_price', (float) $post['fuel_price']);
    writeSettings($conn, 'global', 'elec_price', (float) $post['elec_price']);
    if (isset($post['usb_on'])) {
        setUsbOn($post['usb_on']);
    }

	$ajson['message'] = '数据保存成功！';
    $ajson['success'] = 1;
    returnJson($ajson);
}

$returnData = [];
$returnData['USER_ID'] = readSettings($conn, 'global', 'USER_ID');
$returnData['USER_PASSWORD'] = readSettings($conn, 'global', 'USER_PASSWORD');
$returnData['DIPLUS_AUTH'] = readSettings($conn, 'global', 'DIPLUS_AUTH');
$returnData['filebrowser_url'] = readSettings($conn, 'global', 'filebrowser_url');
$returnData['cover_filename'] = readSettings($conn, 'global', 'cover_filename') ?: 'byd.jpg';
$videolist_show_snapshot = readSettings($conn, 'global', 'videolist_show_snapshot');
$returnData['videolist_show_snapshot'] = $videolist_show_snapshot === '' ? true : $videolist_show_snapshot == 1;
$video_brightness = readSettings($conn, 'global', 'video_brightness');
$video_brightness = strlen($video_brightness) > 0 ? $video_brightness * 1 : 90;
$returnData['video_brightness'] = $video_brightness;
$returnData['move_files_to_sd'] = readSettings($conn, 'global', 'move_files_to_sd') == 1;
$returnData['days_clean_screen_record'] = (int)readSettings($conn, 'global', 'days_clean_screen_record');

$custom_video_dirs = [];
$str = readSettings($conn, 'global', 'custom_video_dirs');
if ($str && $arr = json_decode_x($str)) {
    $custom_video_dirs = $arr;
}
$returnData['custom_video_dirs'] = $custom_video_dirs;
$returnData['fuel_price'] = (float) readSettings($conn, 'global', 'fuel_price') ?: 8;
$returnData['elec_price'] = (float) readSettings($conn, 'global', 'elec_price') ?: 0.55;
$returnData['usb_on'] = getUsbOn();
$returnData['alarm_gyro'] = getCfgVal('AlarmGyro');
$returnData['alarm_gsensor'] = getCfgVal('AlarmGSensor');

$returnData['img_files'] = findImageFiles();
$returnData['version'] = readSettings($conn, 'global', 'version');

$ajson['data'] = $returnData;
$ajson['success'] = 1;
returnJson($ajson);

// 查找图片文件
function findImageFiles() {
    $directory = $_ENV['HOME']."/www/media";
    $patterns = [
        "$directory/*.[jJ][pP][gG]",
        "$directory/*.[jJ][pP][eE][gG]",
        "$directory/*.[pP][nN][gG]",
    ];
    $imageFiles = [];
    foreach ($patterns as $pattern) {
        $files = glob($pattern, GLOB_BRACE);
        if ($files) {
            $files = array_map(fn($file) => basename($file), $files);
            $imageFiles = array_merge($imageFiles, $files);
        }
    }
    return $imageFiles;
}



function getCfgVal($key) {
    $f = '/storage/emulated/0/vandiplus/config_M.dat';
    if (file_exists($f) && preg_match('/' . preg_quote($key) . '=(\w+)/', @file_get_contents($f), $m)) {
        return $m[1];
    }
    return null;
}
// USB 常通电开关 (写入迪加 config_M.dat)
function getUsbOn() {
    $f = '/storage/emulated/0/vandiplus/config_M.dat';
    if (file_exists($f) && preg_match('/UsbAon=(\w+)/', @file_get_contents($f), $m)) {
        return strtolower($m[1]) == 'true';
    }
    return null;
}
function setUsbOn($on) {
    $f = '/storage/emulated/0/vandiplus/config_M.dat';
    $c = @file_get_contents($f);
    if ($c === false) return false;
    $val = $on ? 'true' : 'false';
    if (preg_match('/UsbAon=(\w+)/', $c)) {
        $c = preg_replace('/UsbAon=(\w+)/', 'UsbAon=' . $val, $c, 1);
    } else {
        $c .= "\nUsbAon=" . $val;
    }
    return @file_put_contents($f, $c) !== false;
}
