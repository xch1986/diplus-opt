<?php
// https://apifox.com/apidoc/shared-c3ce5ff5-754f-438c-aef2-055d85aa0391
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$returnData = [
    'cover' => '',
    'coverMs' => 0,
    'events' => []
];
$ajson = [
    'success' => 0,
    'message' => '',
    'data' => $returnData
];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统！';
    returnJson($ajson);
}

$type = $_GET['type'] ?? 0;
$key = $_GET["key"] ?? '';
if (!$key) {
	$ajson['message'] = '参数错误！';
    returnJson($ajson);
}
/**
 * $type
 * 0 - 熄火哨兵
 * 1 - 全景记录仪
 * 2 - 原车行车记录仪
 * 3 - 迪加录屏
 * 4-* - 自定义文件夹
 */

$videoFile = base64_decode($key);
if (!file_exists($videoFile)) {
	$ajson['message'] = '视频文件不存在！';
    returnJson($ajson);    
}
$startTimeMS = explode('_', basename($videoFile))[0];

if ($type == 0 || $type == 1) {
    $conn = db_conn();
    $DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
    $conn = null;
    // 如果视频文件损坏迪加api返回时间会很长，不加超时需要等好几分钟
    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);
    $url = "http://localhost:8988/api/videoInfo?key=$key&auth=".urlencode($DIPLUS_AUTH);
    $res = @file_get_contents($url, false, $context);
    $videoInfo = json_decode_x($res);
    if ($videoInfo) {
        $returnData['cover'] = @$videoInfo['cover'] ?: getVideoCover($videoFile);
        $returnData['coverMs'] = $videoInfo['coverMs'];
    }
    if (isset($videoInfo['labels'])) {
        $events = getEvents($startTimeMS, $videoInfo['labels']);
        $returnData['events'] = $events;
    }

    $ajson['data'] = $returnData;
    $ajson['success'] = !empty($returnData['cover']) ? 1 : 0;
    returnJson($ajson);
}


// $type == 2 原车记录仪, $type == 3 迪加录屏, $type == 4-* 自定义
if ($type == 2 || $type == 3 || preg_match('/^4-(.+)/', $type)) {
    $data = [
        'cover' => '',
        'coverMs' => 1,
        'events' => []
    ];
    $ajson['data']['cover'] = getVideoCover($videoFile, 640, 1);
    if (!$ajson['data']['cover']) {
        $ajson['message'] = '获取视频信息失败！';
        returnJson($ajson);
    }
    $ajson['success'] = 1;
    returnJson($ajson);
}

?>