<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}

$conn = db_conn();

$post = json_decode_x(file_get_contents('php://input'));
if ($post) {
    writeSettings($conn, 'global', 'fuel_price', (float)($post['fuel_price'] ?? 8));
    writeSettings($conn, 'global', 'elec_price', (float)($post['elec_price'] ?? 0.55));
    $ajson['success'] = 1;
    $ajson['message'] = '油价/电价已保存';
    returnJson($ajson);
}

$ajson['data'] = [
    'fuel_price' => (float)readSettings($conn, 'global', 'fuel_price') ?: 8,
    'elec_price' => (float)readSettings($conn, 'global', 'elec_price') ?: 0.55,
];
$ajson['success'] = 1;
returnJson($ajson);
?>
